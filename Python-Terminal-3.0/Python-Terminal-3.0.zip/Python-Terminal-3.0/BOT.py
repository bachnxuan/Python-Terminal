import os

bot_name = 'Bot'
terminal_ver = '3.0'
bot_ver = '1.0.0'
user = os.getlogin()

class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

class BotMsg:
    def CompleteMsg():
        print(f'{bcolors.OKGREEN}{bot_name}: Complete ✔ {bcolors.ENDC}')

    def FailMsg():
        print(f'{bcolors.FAIL}{bot_name}: Error ✘ {bcolors.ENDC}')

    def PythonProjectNotExistMsg():
        print(f'{bcolors.FAIL}{bot_name}: Error ✘ The Python Project Not Exist {bcolors.ENDC}')

    def FileNotFoundMsg():
        print(f'{bcolors.FAIL}{bot_name}: Error ✘ The File Not Exist {bcolors.ENDC}')

    def OpenGameCompleteMsg():
        print(f'{bcolors.OKGREEN}{bot_name}: Open Game Complete ✔ {bcolors.ENDC}')
    
    def OpenMediaPlayerCompleteMsg():
        print(f'{bcolors.OKGREEN}{bot_name}: Open Media Player Complete ✔ {bcolors.ENDC}')

    def OpenPythonShellCompleteMsg():
        print(f'{bcolors.OKGREEN}{bot_name}: Open Python Shell Complete ✔ {bcolors.ENDC}')

    def OpenPythonProjectCompleteMsg():
        print(f'{bcolors.OKGREEN}{bot_name}: Open Python Project Complete ✔ {bcolors.ENDC}')

    def HelpMsg():
        print(f'{bcolors.OKGREEN}{bot_name}: You Can Help ? Type \'help\' Command {bcolors.ENDC}')
    
    def IncorrectCommand():
        print(f'{bcolors.FAIL}{bot_name}: Incorrect Command ✘ {bcolors.ENDC}')
        print(f'{bcolors.OKGREEN}{bot_name}: You Can Help ? Type \'help\' Command {bcolors.ENDC}')

    def BugReportCompleteMsg():
        print(f'{bcolors.OKGREEN}{bot_name}: Report Bug Complete ✔ {bcolors.ENDC}')

    def BotVerMsg():
        print(f'{bcolors.OKGREEN}{bot_name}: Bot Version {bot_ver} {bcolors.ENDC}')

    def KeyBoardInterruptMsg():
        print(f'\n{bcolors.FAIL}{bot_name}: Error ✘ Keyboard Interrupt {bcolors.ENDC}')
        print(f'{bcolors.OKGREEN}{bot_name}: Did You Want To Exit ? Type \'exit\' Command \n {bcolors.ENDC}')

    def WellcomeMsg():
        print(f'{bcolors.OKGREEN}{bot_name}: Hello {user} ! {bcolors.ENDC}')
        print(f'{bcolors.OKGREEN}{bot_name}: {user}, You Are On {terminal_ver} Version {bcolors.ENDC}')

    def GoodbyeMsg():
        print(f'{bcolors.OKGREEN}{bot_name}: Goodbye {user} ! {bcolors.ENDC}')
        print(f'{bcolors.OKGREEN}{bot_name}: {user}, Do You Like Python Terminal ? {bcolors.ENDC}')
